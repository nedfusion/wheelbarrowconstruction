================================================================================
WHEELBARROW CONSTRUCTION LIMITED - DEPLOYMENT PACKAGE
================================================================================

This folder contains all files needed to deploy your website to cPanel hosting.

WHAT'S INCLUDED:
----------------
✓ index.html - Main website file
✓ assets/ - Optimized CSS and JavaScript files
✓ .htaccess - Server configuration for React Router and performance
✓ All images and the video background file
✓ Favicon and logo files

DEPLOYMENT INSTRUCTIONS:
------------------------

STEP 1: Login to your cPanel account

STEP 2: Open File Manager and navigate to "public_html"

STEP 3: Upload ALL files from this dist folder to public_html:
   - index.html
   - .htaccess (important!)
   - assets folder (with all contents)
   - All image files (.jpg, .png)
   - Video file (Wheelbarrow 50 storey .mp4)

STEP 4: Verify the .htaccess file uploaded (it may be hidden)

STEP 5: Visit your domain to test the website

IMPORTANT NOTES:
----------------
• The .htaccess file is hidden - make sure "Show Hidden Files" is enabled
• All files must be in the ROOT of public_html (not in a subfolder)
• Keep the "assets" folder intact with its contents
• The video file is large - ensure it uploads completely

FILE STRUCTURE SHOULD LOOK LIKE:
---------------------------------
public_html/
  ├── index.html
  ├── .htaccess
  ├── assets/
  │   ├── index-C-Pvj90p.css
  │   └── index-yP5b3zgE.js
  ├── Wheelbarrow 50 storey .mp4
  ├── All caps Transparent.png
  └── [all other image files]

TROUBLESHOOTING:
----------------
→ If pages show 404 on refresh: Verify .htaccess file is uploaded
→ If video doesn't play: Check file size uploaded completely
→ If images missing: Verify all files uploaded from dist folder
→ If styles broken: Clear browser cache and check assets folder

For detailed instructions, see: CPANEL_DEPLOYMENT_GUIDE.md

================================================================================
